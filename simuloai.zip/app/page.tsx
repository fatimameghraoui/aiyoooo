import SimuloSite from '@/components/simulo-site'

export default function Page() {
  return <SimuloSite />
}
